import { withAuth } from "next-auth/middleware";

export default withAuth({
  callbacks: {
    authorized: ({ token, req }) => {
      const url = new URL(req.nextUrl);
      if (url.pathname.startsWith("/admin")) {
        return (token as any)?.role === "admin";
      }
      return true;
    },
  },
});

export const config = { matcher: ["/admin/:path*"] };
