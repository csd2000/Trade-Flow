-- CMS content table
create table if not exists public.cms_content (
  id uuid primary key default gen_random_uuid(),
  path text unique not null,
  data jsonb not null default '{}'::jsonb,
  updated_by text,
  updated_at timestamp with time zone default now()
);

-- Admin audit log
create table if not exists public.admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  email text,
  action text,
  path text,
  created_at timestamp with time zone default now()
);

-- enable RLS
alter table public.cms_content enable row level security;
alter table public.admin_audit_log enable row level security;

-- RLS policies (read for all, write via server routes)
drop policy if exists cms_read_all on public.cms_content;
create policy cms_read_all on public.cms_content
  for select using (true);

drop policy if exists cms_audit_read_all on public.admin_audit_log;
create policy cms_audit_read_all on public.admin_audit_log
  for select using (true);
