import { z } from "zod";

export const TrainingModuleSchema = z.object({
  slug: z.string(),
  track: z.string(),
  order: z.number(),
  of: z.number(),
  title: z.string(),
  duration: z.string(),
  overview: z.string(),
  prerequisites: z.array(z.string()),
  steps: z.array(z.string()),
  notes_prompt: z.string().optional(),
  resources: z.object({
    video: z.object({ label: z.string(), url: z.string().url() }).optional(),
    pdf: z.object({ label: z.string(), url: z.string().url() }).optional(),
    community: z.object({ label: z.string(), url: z.string().url() }).optional(),
  }).optional(),
  additional_resources: z.array(z.object({ label: z.string(), url: z.string().url() })).optional(),
  previous: z.object({ label: z.string(), slug: z.string() }).nullable().optional(),
  next: z.object({ label: z.string(), slug: z.string() }).nullable().optional(),
});
