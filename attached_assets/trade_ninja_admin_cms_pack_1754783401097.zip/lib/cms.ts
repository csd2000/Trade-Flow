export async function fetchCMS(path: string) {
  try {
    const r = await fetch(`/api/admin/content?path=${encodeURIComponent(path)}`, { cache: "no-store" });
    if (!r.ok) return null;
    const json = await r.json();
    return json.data;
  } catch { return null; }
}
