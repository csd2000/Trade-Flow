import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { supabase } from "@/lib/supabase";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const path = url.searchParams.get("path");
  if (!path) return NextResponse.json({ error: "Missing path" }, { status: 400 });
  const { data, error } = await supabase.from("cms_content").select("*").eq("path", path).single();
  if (error || !data) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(data);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions as any);
  if (!session || (session as any).role !== "admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  const body = await req.json();
  const { path, data } = body || {};
  if (!path || typeof data === "undefined") {
    return NextResponse.json({ error: "Missing path or data" }, { status: 400 });
  }
  const { data: up, error } = await supabase.from("cms_content")
    .upsert({ path, data, updated_by: (session as any)?.user?.email || "admin" }).select().single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  await supabase.from("admin_audit_log").insert({ email: (session as any)?.user?.email || "admin", action: "update_content", path });
  return NextResponse.json(up);
}
