export default function AdminHome() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <p className="opacity-80 mt-2">Manage content, training modules, strategies, and global settings.</p>
      <div className="grid md:grid-cols-2 gap-4 mt-6">
        <a href="/admin/content" className="rounded-xl border border-[#2C3744] bg-[#232B36] p-4 hover:shadow-xl transition">Content Editor</a>
        <a href="/admin/settings" className="rounded-xl border border-[#2C3744] bg-[#232B36] p-4 hover:shadow-xl transition">App Settings</a>
      </div>
    </div>
  );
}
