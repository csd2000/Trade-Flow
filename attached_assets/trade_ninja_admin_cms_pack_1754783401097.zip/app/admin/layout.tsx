"use client";
import { SessionProvider, useSession } from "next-auth/react";
import Link from "next/link";
import { useRouter } from "next/navigation";

function Guard({ children }: { children: React.ReactNode }) {
  const { data, status } = useSession();
  const router = useRouter();
  if (status === "loading") return null;
  if (!data || (data as any).role !== "admin") { router.push("/"); return null; }
  return <>{children}</>;
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <Guard>
        <div className="min-h-screen flex">
          <aside className="w-16 hover:w-56 transition-all duration-300 bg-[#12171E] text-white p-3 border-r border-[#2C3744] overflow-hidden">
            <div className="text-xs opacity-70 mb-2">ADMIN</div>
            <nav className="space-y-1">
              <Link className="block rounded px-2 py-2 hover:bg-[#1F2630]" href="/admin">Dashboard</Link>
              <Link className="block rounded px-2 py-2 hover:bg-[#1F2630]" href="/admin/content">Content</Link>
              <Link className="block rounded px-2 py-2 hover:bg-[#1F2630]" href="/admin/settings">Settings</Link>
            </nav>
          </aside>
          <main className="flex-1 bg-[#1A1F27] text-white p-6 overflow-y-auto">{children}</main>
        </div>
      </Guard>
    </SessionProvider>
  );
}
