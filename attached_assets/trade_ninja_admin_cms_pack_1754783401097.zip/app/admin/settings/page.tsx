"use client";
import { useState } from "react";

export default function AdminSettings() {
  const [content, setContent] = useState(JSON.stringify({
    theme: { primary: "#22D3EE", card: "#232B36", base: "#1A1F27" },
    features: { orderbook: true, alerts: true, automation: false },
    gates: { premiumRoutes: ["/strategy-builder", "/exit-strategy"] }
  }, null, 2));
  const [status, setStatus] = useState("");

  const load = async () => {
    setStatus("Loading...");
    const r = await fetch(`/api/admin/content?path=${encodeURIComponent("/admin/settings")}`);
    if (!r.ok) { setStatus("Not found"); return; }
    const json = await r.json();
    setContent(JSON.stringify(json.data, null, 2));
    setStatus("Loaded");
  };
  const save = async () => {
    setStatus("Saving…");
    try {
      const body = JSON.parse(content);
      const r = await fetch(`/api/admin/content`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: "/admin/settings", data: body }),
      });
      if (!r.ok) throw new Error("Save failed");
      setStatus("Saved ✅");
    } catch (e) {
      setStatus("Invalid JSON or server error");
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold">Admin Settings</h1>
      <div className="mt-3 flex gap-2">
        <button onClick={load} className="px-3 py-2 rounded bg-cyan-600 hover:bg-cyan-500">Load</button>
        <button onClick={save} className="px-3 py-2 rounded bg-[#1F2630] border border-[#2C3744] hover:bg-[#263140]">Save</button>
        <span className="text-sm opacity-70">{status}</span>
      </div>
      <textarea
        value={content}
        onChange={e=>setContent(e.target.value)}
        className="mt-4 w-full min-h-[60vh] rounded-xl bg-[#1A2431] border border-[#2C3744] p-3 font-mono text-sm"
      />
    </div>
  );
}
