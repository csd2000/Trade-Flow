"use client";
import { useState } from "react";

export default function ContentEditor() {
  const [path, setPath] = useState("/academy/module/passive-income-training/passive-income-module-1");
  const [content, setContent] = useState("{}");
  const [status, setStatus] = useState("");

  const load = async () => {
    setStatus("Loading...");
    const r = await fetch(`/api/admin/content?path=${encodeURIComponent(path)}`);
    if (!r.ok) { setStatus("Not found"); setContent("{}"); return; }
    const json = await r.json();
    setContent(JSON.stringify(json.data, null, 2));
    setStatus("Loaded");
  };
  const save = async () => {
    setStatus("Saving…");
    try {
      const body = JSON.parse(content);
      const r = await fetch(`/api/admin/content`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path, data: body }),
      });
      if (!r.ok) throw new Error("Save failed");
      setStatus("Saved ✅");
    } catch (e) {
      setStatus("Invalid JSON or server error");
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold">Content Editor</h1>
      <div className="mt-4 grid md:grid-cols-[320px_1fr] gap-4">
        <div className="bg-[#232B36] border border-[#2C3744] p-4 rounded-xl">
          <label className="text-sm">Content Path</label>
          <input value={path} onChange={e=>setPath(e.target.value)}
            className="mt-1 w-full rounded bg-[#1A2431] border border-[#2C3744] p-2" />
          <div className="mt-3 flex gap-2">
            <button onClick={load} className="px-3 py-2 rounded bg-cyan-600 hover:bg-cyan-500">Load</button>
            <button onClick={save} className="px-3 py-2 rounded bg-[#1F2630] border border-[#2C3744] hover:bg-[#263140]">Save</button>
          </div>
          <div className="text-sm opacity-70 mt-2">{status}</div>
        </div>
        <textarea
          value={content}
          onChange={e=>setContent(e.target.value)}
          className="w-full min-h-[60vh] rounded-xl bg-[#1A2431] border border-[#2C3744] p-3 font-mono text-sm"
        />
      </div>
    </div>
  );
}
