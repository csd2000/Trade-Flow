const express = require('express');
const app = express();
const port = process.env.PORT || 3001;
const path = require('path');
const fs = require('fs');

const loadJson = (filename) => {
  const filePath = path.join(__dirname, 'data', filename);
  return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
};

app.get('/api/projects', (req, res) => res.json(loadJson('api_projects.json')));
app.get('/api/strategies', (req, res) => res.json(loadJson('api_strategies.json')));
app.get('/api/vaults', (req, res) => res.json(loadJson('api_vaults.json')));
app.get('/api/portfolio', (req, res) => res.json(loadJson('api_portfolio.json')));
app.get('/api/alerts', (req, res) => res.json(loadJson('api_alerts.json')));
app.get('/api/education', (req, res) => res.json(loadJson('api_education.json')));

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});