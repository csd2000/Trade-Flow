# Deployment Instructions

## 🔧 Express.js (Local / Replit)
1. Go to the `express-api/` directory
2. Run `npm install`
3. Run `node server.js` (or `npm start`)
4. Access the API at `http://localhost:3001/api/projects`, etc.

## 🚀 Next.js (Vercel or Replit)
1. Place the `pages/api` files into your Next.js project
2. Ensure `data/` contains all .json files
3. Deploy using `vercel` CLI or Replit's Next.js template
4. API routes will be live at `/api/projects`, etc.