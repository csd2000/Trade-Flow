import strategies from '../../data/api_strategies.json';
export default function handler(req, res) {
  res.status(200).json(strategies);
}