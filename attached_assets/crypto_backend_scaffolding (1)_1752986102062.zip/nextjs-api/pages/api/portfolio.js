import portfolio from '../../data/api_portfolio.json';
export default function handler(req, res) {
  res.status(200).json(portfolio);
}