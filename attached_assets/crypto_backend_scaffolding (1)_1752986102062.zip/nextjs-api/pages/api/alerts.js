import alerts from '../../data/api_alerts.json';
export default function handler(req, res) {
  res.status(200).json(alerts);
}