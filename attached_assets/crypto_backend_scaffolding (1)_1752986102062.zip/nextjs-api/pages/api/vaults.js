import vaults from '../../data/api_vaults.json';
export default function handler(req, res) {
  res.status(200).json(vaults);
}