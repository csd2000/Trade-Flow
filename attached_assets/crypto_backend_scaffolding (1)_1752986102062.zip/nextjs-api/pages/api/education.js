import education from '../../data/api_education.json';
export default function handler(req, res) {
  res.status(200).json(education);
}